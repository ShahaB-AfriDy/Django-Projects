from Helloworld import Max_Digit

List = [44,22,-3,5,93,2,39,45]
print(List)
max_num = Max_Digit(List)

print(max_num)
